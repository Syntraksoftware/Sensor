#include "BLEDevice.h"
#include "BLEServer.h"
#include "BLEUtils.h"
#include "BLE2902.h"

BLECharacteristic *pTxCharacteristic;
bool deviceConnected = false;

unsigned long totalPacketsSent = 0;
unsigned long lastBenchmarkTime = 0;
float packetsPerSecond = 0.0;

unsigned long packetSequenceNumber = 0;

#define SERVICE_UUID           "6E400001-B5A3-F393-E0A9-E50E24DCCA9E"
#define CHARACTERISTIC_UUID_RX "6E400002-B5A3-F393-E0A9-E50E24DCCA9E"
#define CHARACTERISTIC_UUID_TX "6E400003-B5A3-F393-E0A9-E50E24DCCA9E"

class MyServerCallbacks : public BLEServerCallbacks {
  void onConnect(BLEServer* pServer) {
    deviceConnected = true;
    Serial.println("Target device connected!");
    pServer->updateConnParams(pServer->getConnId(), 6, 12, 0, 60);
  };
  void onDisconnect(BLEServer* pServer) {
    deviceConnected = false;
    Serial.println("Target device disconnected. Re-advertising...");
    pServer->startAdvertising(); 
  }
};

void setupBLE(String BLEName) {
  BLEDevice::init(BLEName.c_str());
  BLEServer *pServer = BLEDevice::createServer();
  pServer->setCallbacks(new MyServerCallbacks());
  
  BLEService *pService = pServer->createService(SERVICE_UUID);
  
  pTxCharacteristic = pService->createCharacteristic(CHARACTERISTIC_UUID_TX, BLECharacteristic::PROPERTY_NOTIFY);
  pTxCharacteristic->addDescriptor(new BLE2902());
  
  BLECharacteristic *pRxCharacteristic = pService->createCharacteristic(CHARACTERISTIC_UUID_RX, BLECharacteristic::PROPERTY_WRITE);
  
  pService->start();
  pServer->getAdvertising()->start();
  Serial.println("BLE Interface initialized successfully.");
}

void setup() {
  Serial.begin(115200);
  while(!Serial) { delay(10); } 
  
  setupBLE("ESP32_S3_Speed_Test");
  lastBenchmarkTime = millis();
}

void loop() {
  unsigned long currentTime = millis();
  if (currentTime - lastBenchmarkTime >= 1000) {
    
    if (deviceConnected && totalPacketsSent > 0) {
      packetsPerSecond = (float)totalPacketsSent / ((float)(currentTime - lastBenchmarkTime) / 1000.0);
      float latencyMs = 1000.0 / packetsPerSecond;
      String speedReport = "\r\n--- BENCHMARK: " + String(packetsPerSecond, 1) + " Hz | Latency: " + String(latencyMs, 2) + " ms ---\r\n\r\n";
      
      pTxCharacteristic->setValue((uint8_t*)speedReport.c_str(), speedReport.length());
      pTxCharacteristic->notify();
    }

    totalPacketsSent = 0;
    lastBenchmarkTime = currentTime;
  }

  if (deviceConnected) {
    totalPacketsSent++;
    packetSequenceNumber++;
    
    float yaw   = (random(-1800, 1800) / 10.0);
    float pitch = (random(-900, 900) / 10.0);
    float roll  = (random(-1800, 1800) / 10.0);
    float posX  = (random(-500, 500) / 100.0);
    float posY  = (random(-500, 500) / 100.0);
    float posZ  = (random(-500, 500) / 100.0);

    // Build standard CSV (Comma-Separated Value) structural data frame
    // Format: [Index], [Yaw], [Pitch], [Roll], [X], [Y], [Z]
    String dataFrame = "#" + String(packetSequenceNumber) + ",";
    dataFrame += String(yaw, 1) + "," + String(pitch, 1) + "," + String(roll, 1) + ",";
    dataFrame += String(posX, 2) + "," + String(posY, 2) + "," + String(posZ, 2) + "\r\n";

    pTxCharacteristic->setValue((uint8_t*)dataFrame.c_str(), dataFrame.length());
    pTxCharacteristic->notify();
    
    // time to safely step-queue packets
    delay(1); 
  }
}