#include <WiFi.h>
#include <WebServer.h>
#include <WebSocketsServer.h>

// Access Point credentials
const char* ssid = "ESP32_S3_DualCore";
const char* password = "12345678";

WebServer server(80);
WebSocketsServer webSocket = WebSocketsServer(81);

const int LED_PIN = 48;

// Shared Global Variables for data sharing between Cores
// "volatile" tells the compiler that these values can change at any millisecond across cores
volatile float imu_yaw = 0.0, imu_pitch = 0.0, imu_roll = 0.0;
volatile float imu_x = 0.0, imu_y = 0.0, imu_z = 0.0;

// FreeRTOS Task Handles
TaskHandle_t NetworkTaskHandle;
TaskHandle_t SensorTaskHandle;

// Global HTML String
const char* htmlPage = R"rawliteral(
<!DOCTYPE html>
<html>
<head>
  <title>ESP32 S3 Dual-Core Test</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    body { font-family: 'Segoe UI', Arial, sans-serif; text-align: center; background: #1a1a1a; color: #fff; margin: 0; padding: 20px; }
    .card { background: #2d2d2d; max-width: 450px; margin: 20px auto; padding: 25px; border-radius: 15px; box-shadow: 0 4px 20px rgba(0,0,0,0.5); }
    h1 { color: #00ff88; font-size: 22px; margin-bottom: 25px; }
    .metric { font-size: 32px; font-weight: bold; margin: 10px 0 25px 0; color: #00d2ff; }
    .data-stream { background: #111; color: #00ff88; font-family: monospace; padding: 12px; border-radius: 8px; text-align: left; height: 45px; overflow: hidden; font-size: 13px; white-space: nowrap; text-overflow: ellipsis; }
    .label { font-size: 12px; color: #aaa; text-transform: uppercase; letter-spacing: 1px; font-weight: 600; }
    .divider { height: 1px; background: #444; margin: 20px 0; }
  </style>
</head>
<body>
  <div class="card">
    <h1>ESP32-S3 Dual-Core Engine</h1>
    <div class="label">Round-Trip Latency</div>
    <div class="metric" id="latency">-- ms</div>
    <div class="divider"></div>
    <div class="label">Transmission Speed</div>
    <div class="metric" id="pollingRate">-- Hz</div>
    <div class="divider"></div>
    <div class="label">Live Dual-Core Frame</div>
    <div class="data-stream" id="imuData">Connecting...</div>
  </div>
  <script>
    let packetCount = 0;
    let lastMetricTime = performance.now();
    let gateway = `ws://${window.location.hostname}:81/`;
    let websocket;
    let pingStartTime;

    function initWebSocket() {
      websocket = new WebSocket(gateway);
      websocket.onopen = () => { sendPing(); };
      websocket.onmessage = (event) => {
        const latency = performance.now() - pingStartTime;
        document.getElementById('latency').innerText = latency.toFixed(1) + " ms";
        document.getElementById('imuData').innerText = event.data;
        packetCount++;

        const now = performance.now();
        if (now - lastMetricTime >= 1000) {
          document.getElementById('pollingRate').innerText = packetCount + " Hz";
          packetCount = 0;
          lastMetricTime = now;
        }
        sendPing();
      };
    }
    function sendPing() {
      pingStartTime = performance.now();
      websocket.send('p');
    }
    window.onload = initWebSocket;
  </script>
</body>
</html>
)rawliteral";

void handleRoot() {
  server.send(200, "text/html", htmlPage);
}

// WebSocket Event Handler
void webSocketEvent(uint8_t num, WStype_t type, uint8_t * payload, size_t length) {
  if (type == WStype_TEXT && payload[0] == 'p') {
    // Instantly pack the latest global values updated by Core 1
    String dataFrame = "Core1 YPR: [" + String(imu_yaw, 1) + "," + String(imu_pitch, 1) + "," + String(imu_roll, 1) + 
                       "] | XYZ: [" + String(imu_x, 2) + "," + String(imu_y, 2) + "," + String(imu_z, 2) + "]";
    webSocket.sendTXT(num, dataFrame);
  }
}

// ==========================================
// TASK 1: RUNS INFINITELY ON CORE 0 (Networking)
// ==========================================
void NetworkTask(void * pvParameters) {
  Serial.print("Network Task running on Core: ");
  Serial.println(xPortGetCoreID());

  // Setup local servers inside this core thread
  server.on("/", handleRoot);
  server.begin();
  webSocket.begin();
  webSocket.onEvent(webSocketEvent);

  for (;;) {
    server.handleClient();
    webSocket.loop();
    vTaskDelay(1 / portTICK_PERIOD_MS); // FreeRTOS micro-yield to keep core background healthy
  }
}

// ==========================================
// TASK 2: RUNS INFINITELY ON CORE 1 (IMU Sampling)
// ==========================================
void SensorTask(void * pvParameters) {
  Serial.print("Sensor Task running on Core: ");
  Serial.println(xPortGetCoreID());

  for (;;) {
    rgbLedWrite(LED_PIN, 0, 15, 0); // Blink light on core 1 processing loop

    // Mimic tight, non-stop physical IMU hardware calculations
    imu_yaw   = (random(-1800, 1800) / 10.0);
    imu_pitch = (random(-900, 900) / 10.0);
    imu_roll  = (random(-1800, 1800) / 10.0);
    imu_x     = (random(-500, 500) / 100.0);
    imu_y     = (random(-500, 500) / 100.0);
    imu_z     = (random(-500, 500) / 100.0);

    rgbLedWrite(LED_PIN, 0, 0, 0);

    // Run this simulation sensor read loop every 2 milliseconds (~500Hz)
    vTaskDelay(2 / portTICK_PERIOD_MS); 
  }
}

void setup() {
  Serial.begin(115200);
  while(!Serial) { delay(10); }

  // WiFi.setSleep(WIFI_PHY_SLEEP_DISABLE);
  WiFi.softAP(ssid, password);

  // ------------------------------------------------------------------
  // CREATING THE CORES TASKS VIA FREERTOS
  // ------------------------------------------------------------------
  
  // Syntax: xTaskCreatePinnedToCore(Function, "Name", StackSize, Parameter, Priority, Handle, CoreID)
  
  xTaskCreatePinnedToCore(
    NetworkTask,       /* Function to implement the task */
    "NetworkTask",     /* Name of the task */
    8192,              /* Stack size in words (Adjusted high for WebSockets) */
    NULL,              /* Task input parameter */
    2,                 /* Priority of the task (higher number = higher priority) */
    &NetworkTaskHandle,/* Task handle to keep track of thread */
    0                  /* Core ID: Pin to Core 0 */
  );

  xTaskCreatePinnedToCore(
    SensorTask,
    "SensorTask",
    4096,
    NULL,
    1,                 /* Slightly lower priority so radio packets get priority */
    &SensorTaskHandle,
    1                  /* Core ID: Pin to Core 1 */
  );
}

void loop() {
  // Empty! Since tasks are pinned to distinct cores inside setup(), 
  // the main Arduino loop() thread is no longer needed and handles nothing.
  vTaskDelete(NULL); // Deletes this empty baseline loop task to save RAM resource bytes
}