# ESP32-S3-N16R8

This repository documents the features of the development board ESP32-S3-N16R8.

Under the examples folders there are sample code to interface with built in bluetooth module and wifi module on the ESP32.
## Requirements
- Computer running MacOS/Windows/Linux 
- Arduino IDE ([Link to install](https://www.arduino.cc/en/software/))

## Setting Up the IDE
1. Open the IDE and go to **Preferences** (MacOS: ArduinoIDE tab > Settings; Windows: File > Preferences)
2. Copy the following link into the “Additional Board Manager URLs” field.
```
https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_index.json
```
3. Open the Boards Manager. Go to **Tools > Board > Boards Manager…** and search for `esp32`
4. Press the install button for `ESP32 by Espressif Systems` (This installs the required libraries for ESP32 boards)

## Flashing Code to the board
1. Connect the ESP32 board (**From the port labelled `COM`**) to your computer with a Type-C wire 
2. Go to **tools> board:** and select the board model (i.e. `ESP32S3 Dev Module`)
3. Go to **tools> Port:** and select the Port corresponding to the board (Should be in the format `/dev/cu.usbmodemSomeHex` for Mac and COMx for Windows)
5. Copy the code in examples to the code area 
6. Press the **Upload** button (Right arrow icon) on the top left corner. Wait a few seconds while the code compiles and uploads to your board
7. If everything went as expected, you should see a “Done uploading.” message.

## Further Reading
References on basic control with ESP32: https://www.oceanlabz.in/getting-started-with-esp32-wi-fi/?srsltid=AfmBOoqVlOhe16qIMCWZrFzw0hOOi_AHuni0gYUeEDMWoD0e60hKY_Az

