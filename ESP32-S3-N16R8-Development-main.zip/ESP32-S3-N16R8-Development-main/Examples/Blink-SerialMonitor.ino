
#define LED_PIN 48 // NeoPixel on ESP32s3

void setup() {
Serial.begin(112500);
delay(100);
  Serial.println("test");
}

void loop() {
  // Your code here
  Serial.println("aa");
  rgbLedWrite(LED_PIN, 150, 0, 0);
  delay(500);
  rgbLedWrite(LED_PIN, 0, 150, 0);
  delay(500);
  rgbLedWrite(LED_PIN, 0, 0, 150);
  delay(500);
}
