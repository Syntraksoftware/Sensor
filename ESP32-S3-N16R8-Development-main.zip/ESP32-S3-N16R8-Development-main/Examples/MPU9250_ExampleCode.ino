#include <Wire.h>
#include <MPU9250.h>

MPU9250 mpu;

#define I2C_SDA 20
#define I2C_SCL 21

void setup() {
    Serial.begin(115200);
    while (!Serial) delay(10);

    Wire.begin(I2C_SDA, I2C_SCL);
    delay(2000);

    if (!mpu.setup(0x68)) {
        while (1) {
            Serial.println("MPU9250 connection failed. Check wiring!");
            delay(5000);
        }
    }

    Serial.println("MPU9250 Initialized Successfully!");
}

void loop() {
    // Check if new data is available from the sensor registers
    if (mpu.update()) {
    
        Serial.print(mpu.getAccX(), 2); Serial.print(",");
        Serial.print(mpu.getAccY(), 2); Serial.print(",");
        Serial.print(mpu.getAccZ(), 2); Serial.print(",");
        
        Serial.print(mpu.getGyroX(), 2); Serial.print(",");
        Serial.print(mpu.getGyroY(), 2); Serial.print(",");
        Serial.print(mpu.getGyroZ(), 2); Serial.print(",");
        
        Serial.print(mpu.getMagX(), 2); Serial.print(",");
        Serial.print(mpu.getMagY(), 2); Serial.print(",");
        Serial.println(mpu.getMagZ(), 2); // Prints newline break '\n'
    }
    
    delay(10); // Continuous stream tracking around 100Hz
}
