#include "BLEDevice.h"
#include "BLEServer.h"
#include "BLEUtils.h"
#include "BLE2902.h"

BLECharacteristic *pTxCharacteristic;
bool deviceConnected = false;
unsigned int counter = 0; 
long lastMsg = 0;

// recognize ESP on Bluetooth 
#define SERVICE_UUID           "6E400001-B5A3-F393-E0A9-E50E24DCCA9E"
#define CHARACTERISTIC_UUID_RX "6E400002-B5A3-F393-E0A9-E50E24DCCA9E"
#define CHARACTERISTIC_UUID_TX "6E400003-B5A3-F393-E0A9-E50E24DCCA9E"

// checks if ESP is connected to device
class MyServerCallbacks : public BLEServerCallbacks {
  void onConnect(BLEServer* pServer) {
    deviceConnected = true;
    Serial.println("\n[BLE] App Connected!");
  };
  void onDisconnect(BLEServer* pServer) {
    deviceConnected = false;
    Serial.println("\n[BLE] App Disconnected. Broadcasting signal...");
    pServer->startAdvertising(); // Send signal for device to detect
  }
};

// listens to your Serial Bluetooth Monitor on device (Uses Interrupt Callback)
class MyRxCallbacks : public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic *pCharacteristic) {
    String rxValue = pCharacteristic->getValue(); // received value

    if (rxValue.length() > 0) {    
      for (int i = 0; i < rxValue.length(); i++) {
        Serial.print(rxValue[i]);
      }
    }
  }
};

void setupBLE(String BLEName) {
  BLEDevice::init(BLEName.c_str());
  BLEServer *pServer = BLEDevice::createServer();
  pServer->setCallbacks(new MyServerCallbacks());
  
  BLEService *pService = pServer->createService(SERVICE_UUID);
  
  // TX channel from ESP32-S3 to device
  pTxCharacteristic = pService->createCharacteristic(CHARACTERISTIC_UUID_TX, BLECharacteristic::PROPERTY_NOTIFY);
  pTxCharacteristic->addDescriptor(new BLE2902());
  // RX channel from device to ESP32-S3
  BLECharacteristic *pRxCharacteristic = pService->createCharacteristic(CHARACTERISTIC_UUID_RX, BLECharacteristic::PROPERTY_WRITE);
  
  // callback for receiving data from device
  pRxCharacteristic->setCallbacks(new MyRxCallbacks());
  
  pService->start();
  pServer->getAdvertising()->start();
  Serial.println("BLE Interface initialized successfully.");
}

void setup() {
  Serial.begin(115200);
  while(!Serial) { delay(10); } 
  
  setupBLE("ESP32_S3_Bluetooth");
}

void loop() {
  long now = millis();
  if (now - lastMsg > 100) { 
    lastMsg = now; // sends a message every 100 ms
    
    if (deviceConnected) {
      counter++; 
      String payload = String(counter) + "\r\n";
      pTxCharacteristic->setValue((uint8_t*)payload.c_str(), payload.length());
      pTxCharacteristic->notify();
    }
  }
}