#include <WiFi.h>
#include <HTTPClient.h>

const char* ssid     = "WIFI Name";
const char* password = "WIFI Password (Leave blank if no password)";

// Replace with your laptop's local IP address from Step 1
const char* laptopServerUrl = "Server URL"; 

void setup() {
  Serial.begin(115200);
  
  // Make sure USB serial monitor is listening
  while(!Serial) { delay(10); }

  WiFi.begin(ssid, password);
  Serial.print("Connecting to Wi-Fi");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nConnected to Wi-Fi network!");
}

void loop() {
  if (WiFi.status() == WL_CONNECTED) {
    HTTPClient http;

    // find target endpoint on your laptop
    http.begin(laptopServerUrl);
    http.addHeader("Content-Type", "application/json");

    // Simulate sensor readouts
    float temp = random(220, 280) / 10.0;
    float hum  = random(450, 600) / 10.0;

    // Format raw payload strings into structural JSON
    String jsonPayload = "{\"temperature\":" + String(temp, 1) + ",\"humidity\":" + String(hum, 1) + "}";
    
    Serial.print("Pushing data to laptop... ");
    int httpResponseCode = http.POST(jsonPayload);

    if (httpResponseCode > 0) {
      String response = http.getString();
      Serial.print("Success! Code: ");
      Serial.println(httpResponseCode);
    } else {
      Serial.print("Error sending POST: ");
      Serial.println(httpResponseCode);
    }

    http.end();
  }

  delay(1000); // Send data every 3 seconds
}